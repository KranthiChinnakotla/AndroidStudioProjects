package com.medha.inclass05;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class MainActivity extends AppCompatActivity {


    String result[];
    String splitResult[] ;
    ArrayList<String> resultList = new ArrayList<String>();
    ArrayList<String> maps = new ArrayList<String>();
    ArrayList<String> keys = new ArrayList<String>();
    HashMap<String,String> photos = new HashMap<String,String>();
    EditText editText;
    Button buttonGo;
    ImageView imageView;
    ImageButton imNext,imPrev;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = (EditText) findViewById(R.id.editText_search);
        buttonGo = (Button) findViewById(R.id.button_go);
        imageView = (ImageView) findViewById(R.id.imageView);
        new GetList().execute("http://dev.theappsdr.com/apis/spring_2016/inclass5/URLs.txt");

        buttonGo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (isConnectedOnline()) {

                    for (String s : photos.keySet()) {

                        if (editText.getText().toString().equals(s)) {
                            new RequestParams(MainActivity.this).execute(photos.get(s));
                        }
                    }
                } else
                    Toast.makeText(MainActivity.this, "Not Connected", Toast.LENGTH_LONG).show();
            }
        });


        imNext = (ImageButton) findViewById(R.id.imageButton_next);
        imNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (isConnectedOnline()){

                }
                else
                    Toast.makeText(MainActivity.this, "Not Connected", Toast.LENGTH_LONG).show();

            }
        });

        imPrev = (ImageButton) findViewById(R.id.imageButton_prev);
        imPrev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isConnectedOnline()){

                }
                else
                    Toast.makeText(MainActivity.this, "Not Connected", Toast.LENGTH_LONG).show();

            }
        });



    }

    private boolean isConnectedOnline(){
        ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = cm.getActiveNetworkInfo();
        if(networkInfo != null && networkInfo.isConnected()){
            return true;
        }
        return false;
    }

    private class GetList extends AsyncTask<String,Void,String>{

        BufferedReader reader = null;
        @Override
        protected String doInBackground(String... strings) {

            try {
                URL url = new URL(strings[0]);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("GET");
                reader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                String line = "";
                StringBuilder sb = new StringBuilder();
                while((line=reader.readLine())!=null){
                    sb.append(line);
                }
               return sb.toString();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            finally {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }


            return null;
        }

        @Override
        protected void onPostExecute(String s) {

            if(s!=null) {
                result = s.split(";");

                for(String str: result){
                    splitResult = str.split(",");
                     for(String stri: splitResult){
                         resultList.add(stri);
                     }
                }
            }


            int j = 0;
            for (int i=0; i<resultList.size();i++){

                j=i+1;
                if (i==0) {
                maps.add(resultList.get(i));
                }
                if(i==1) {
                    keys.add(resultList.get(i));
                }

                if(i>1 && i<resultList.size()){
                    if(j/2 == 0){
                        maps.add(resultList.get(i));
                    }
                    else if (j/2 != 0){
                        keys.add(resultList.get(i));
                    }
                }



            }



            for(String m: maps){
                for(String k: keys)
                    photos.put(m,k);

            }

        }
    }
}



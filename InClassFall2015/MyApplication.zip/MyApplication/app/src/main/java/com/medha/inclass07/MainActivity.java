package com.medha.inclass07;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import org.json.JSONException;

import java.util.ArrayList;



public class MainActivity extends AppCompatActivity implements GetItunesApp.InputList {

    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = (ListView) findViewById(R.id.listView);

        new GetItunesApp(this).execute("http://itunes.apple.com/us/rss/topgrossingapplications/limit=25/json");


    }

    @Override
    public void inputlist(ArrayList<Itunes> itunes) {

        ItunesArrayadapter adapter = new ItunesArrayadapter(MainActivity.this,R.layout.layout,itunes);
        adapter.setNotifyOnChange(true);
        listView.setAdapter(adapter);


    }
}
